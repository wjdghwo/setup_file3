from bleach._vendor.parse import urlparse  # noqa
